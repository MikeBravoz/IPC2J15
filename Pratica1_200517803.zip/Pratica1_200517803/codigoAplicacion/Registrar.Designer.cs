﻿namespace WhizzHardBooks
{
    partial class Registrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registrar));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtnombreus = new System.Windows.Forms.TextBox();
            this.txtdpius = new System.Windows.Forms.TextBox();
            this.txtdireccionus = new System.Windows.Forms.TextBox();
            this.txttelefonous = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblcarnet = new System.Windows.Forms.Label();
            this.btnInicio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(252, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "DATOS DE USUARIO";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(242, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "NOMBRE    ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(242, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "DPI             ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(242, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "DIRECCION";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(242, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "TELEFONO ";
            // 
            // txtnombreus
            // 
            this.txtnombreus.Location = new System.Drawing.Point(331, 71);
            this.txtnombreus.Name = "txtnombreus";
            this.txtnombreus.Size = new System.Drawing.Size(100, 20);
            this.txtnombreus.TabIndex = 5;
            // 
            // txtdpius
            // 
            this.txtdpius.Location = new System.Drawing.Point(331, 103);
            this.txtdpius.Name = "txtdpius";
            this.txtdpius.Size = new System.Drawing.Size(100, 20);
            this.txtdpius.TabIndex = 6;
            // 
            // txtdireccionus
            // 
            this.txtdireccionus.Location = new System.Drawing.Point(331, 139);
            this.txtdireccionus.Name = "txtdireccionus";
            this.txtdireccionus.Size = new System.Drawing.Size(100, 20);
            this.txtdireccionus.TabIndex = 7;
            // 
            // txttelefonous
            // 
            this.txttelefonous.Location = new System.Drawing.Point(331, 172);
            this.txttelefonous.Name = "txttelefonous";
            this.txttelefonous.Size = new System.Drawing.Size(100, 20);
            this.txttelefonous.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(246, 209);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 38);
            this.button1.TabIndex = 9;
            this.button1.Text = "REGISTRAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblcarnet
            // 
            this.lblcarnet.AutoSize = true;
            this.lblcarnet.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcarnet.Location = new System.Drawing.Point(252, 262);
            this.lblcarnet.Name = "lblcarnet";
            this.lblcarnet.Size = new System.Drawing.Size(151, 23);
            this.lblcarnet.TabIndex = 10;
            this.lblcarnet.Text = "Numero de Carnet";
            this.lblcarnet.Visible = false;
            // 
            // btnInicio
            // 
            this.btnInicio.Location = new System.Drawing.Point(53, 316);
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.Size = new System.Drawing.Size(123, 47);
            this.btnInicio.TabIndex = 11;
            this.btnInicio.Text = "INICIO";
            this.btnInicio.UseVisualStyleBackColor = true;
            this.btnInicio.Click += new System.EventHandler(this.button2_Click);
            // 
            // Registrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(548, 375);
            this.Controls.Add(this.btnInicio);
            this.Controls.Add(this.lblcarnet);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txttelefonous);
            this.Controls.Add(this.txtdireccionus);
            this.Controls.Add(this.txtdpius);
            this.Controls.Add(this.txtnombreus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Registrar";
            this.Text = "Registrar";
            this.Load += new System.EventHandler(this.Registrar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtnombreus;
        private System.Windows.Forms.TextBox txtdpius;
        private System.Windows.Forms.TextBox txtdireccionus;
        private System.Windows.Forms.TextBox txttelefonous;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblcarnet;
        private System.Windows.Forms.Button btnInicio;
    }
}